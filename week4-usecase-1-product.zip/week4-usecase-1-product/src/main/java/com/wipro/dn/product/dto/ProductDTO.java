package com.wipro.dn.product.dto;

public class ProductDTO {
    private int id;
    private String description;
    private String category;
    private int qty;
    private double price;

    // Default constructor
    public ProductDTO() {
    }

    // Parameterized constructor
    public ProductDTO(int id, String description, String category, int qty, double price) {
        this.id = id;
        this.description = description;
        this.category = category;
        this.qty = qty;
        this.price = price;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
