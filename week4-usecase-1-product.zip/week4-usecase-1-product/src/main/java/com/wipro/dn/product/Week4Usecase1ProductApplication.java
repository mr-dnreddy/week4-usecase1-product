package com.wipro.dn.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week4Usecase1ProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week4Usecase1ProductApplication.class, args);
	}

}
