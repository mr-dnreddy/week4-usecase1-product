package com.wipro.dn.product.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.dn.product.dto.ProductDTO;
import com.wipro.dn.product.entity.Product;
import com.wipro.dn.product.productrepo.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public ProductDTO saveProduct(ProductDTO productDTO) {
        Product product = new Product(
                productDTO.getDescription(),
                productDTO.getCategory(),
                productDTO.getQty(),
                productDTO.getPrice()
        );
        Product savedProduct = productRepository.save(product);
        return convertToDTO(savedProduct);
    }

    public List<ProductDTO> getAllProducts() {
        return productRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public Optional<ProductDTO> getProductById(int id) {
        return productRepository.findById(id)
                .map(this::convertToDTO);
    }

    public void deleteProductById(int id) {
        productRepository.deleteById(id);
    }

    public ProductDTO updateProduct(ProductDTO productDTO) {
        Product product = new Product(
                productDTO.getDescription(),
                productDTO.getCategory(),
                productDTO.getQty(),
                productDTO.getPrice()
        );
        product.setId(productDTO.getId()); // Ensure the ID is set for updating
        Product updatedProduct = productRepository.save(product);
        return convertToDTO(updatedProduct);
    }

    private ProductDTO convertToDTO(Product product) {
        return new ProductDTO(
                product.getId(),
                product.getDescription(),
                product.getCategory(),
                product.getQty(),
                product.getPrice()
        );
    }
}
