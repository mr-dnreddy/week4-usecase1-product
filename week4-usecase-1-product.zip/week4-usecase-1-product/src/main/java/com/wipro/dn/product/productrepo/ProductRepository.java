package com.wipro.dn.product.productrepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wipro.dn.product.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	
}