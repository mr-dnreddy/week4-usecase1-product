package com.wipro.dn.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4Usecase1ProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
